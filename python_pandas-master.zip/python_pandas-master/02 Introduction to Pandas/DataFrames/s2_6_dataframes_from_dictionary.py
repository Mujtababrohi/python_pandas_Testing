import pandas as pd

# Create a dictionary of sales data
# course_sales = {'course':['Python','Ruby','Excel','C++'],
#                'day':['Mon','Tue','Wed','Tue'],
#                'price':[5,10,15,20],
#                'sale':[2,3,5,7]
#                }

# Convert sales data into a DataFrame
# df_sales = pd.DataFrame(course_sales)
# print(df_sales)

# Create indidivdual lists from sales data
# course = ['Python','Ruby','Excel','C++']

# day = ['Mon', 'Tue', 'Tue', 'Wed']

# price = [5,10,15,20]

# sale = [2,3,5,7]

# Create a list of column labels
# column_labels = ['Course', 'Day', 'Price', 'Sale']

# Add a list of column entries for each column
# column_names = [course,day,price,sale]

# Combine list of column labels and column names above to create a new single list
# master_list = list(zip(column_labels,column_names))
# print(master_list)

# Convert master list to a dictionary
# sales_data = dict(master_list)

# Convert master list dictionary to a DataFrame
# df_sales = pd.DataFrame(sales_data)
# print(df_sales)
