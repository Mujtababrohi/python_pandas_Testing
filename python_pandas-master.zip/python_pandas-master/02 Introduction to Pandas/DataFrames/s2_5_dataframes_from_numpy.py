import numpy as np
import pandas as pd

# Create a numpy array
# new_array = np.arange(0,10).reshape(2,5)
# print(new_array)

# Convert numpy array into DataFrame
# df = pd.DataFrame(data=new_array, columns=['A', 'B', 'C', 'D', 'E'])
# print(df)
