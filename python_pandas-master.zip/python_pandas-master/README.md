# Python Pandas: Data Manipulation & Analysis

Source location for Python Pandas: Data Manipulation & Analysis

## Useful links:

- https://www.anaconda.com/
- https://conda.io/docs/index.html
- https://conda.io/docs/_downloads/conda-cheatsheet.pdf
- https://www.google.com/publicdata/directory
- https://www.kaggle.com
- https://docs.scipy.org/doc/numpy-1.13.0/


## Errors encountered along the way
- Error after updateing to macOS Mojave
xcrun: error: invalid active developer path (/Library/Developer/CommandLineTools),
missing xcrun at: /Library/Developer/CommandLineTools/usr/bin/xcrun
https://apple.stackexchange.com/questions/254380/macos-mojave-invalid-active-developer-path

- Error when trying to clone a Git repo in Atom
https://stackoverflow.com/questions/4492979/git-is-not-recognized-as-an-internal-or-external-command
